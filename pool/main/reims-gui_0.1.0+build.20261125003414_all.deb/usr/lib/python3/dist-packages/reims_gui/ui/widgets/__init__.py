"""UI widgets package."""
